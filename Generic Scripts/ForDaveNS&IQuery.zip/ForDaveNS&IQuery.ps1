﻿
$strSharePointSiteURL = "https://uam.ms.myatos.net/"
$newarray  =@()
[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")
    $ctx = New-Object Microsoft.SharePoint.Client.ClientContext($strSharePointSiteURL)
    [System.Net.CredentialCache]$credentials = New-Object -TypeName System.Net.CredentialCache
    $ctx.Credentials = $credentials.DefaultNetworkCredentials;
    $ctx.RequestTimeOut = 5000 * 60 * 10
    $web = $ctx.Web
    $list = $web.Lists.GetByTitle("Application Tracker")
    $camlQuery = New-Object Microsoft.SharePoint.Client.CamlQuery
    $camlQuery.ViewXml = "<View>
<Query>
<Where>
  <Eq>
    <FieldRef Name='Client'></FieldRef>
    <Value Type='Text'>National Savings and Investments</Value>
  </Eq>
</Where>
</Query>
<RowLimit>1000</RowLimit>
</View>"
    $spListItemCollection = $List.GetItems($camlQuery)
    $ctx.Load($spListItemCollection)
    $ctx.ExecuteQuery()
    foreach ($item in $spListItemCollection){
        $1 = $item['Title']
        $2 = $item['ApplicationStatus']       
        $3 = $item['ApplicationVendor0']
        $3 = $3.LookupValue;
        $4 = $item['ApplicationName']
        $5 = $item['ApplicationVersion']
        $6 = $item['PackageArchitecture']
        $7 = $item['Complexity']
        $9 = $item['Package_x0020_archive_x0020_name']

        $newarray += New-Object PsObject -Property @{
        
        Title = $1 ;
        Application_x0020_status = $2  ;   
        Application_x0020_Vendor = $3;
        Application_x0020_name = $4;
        Application_x0020_version = $5;
        Package_x0020_architecture = $6;
        Complexity = $7;
        Package_x0020_archive_x0020_name = $9;
        
        
        }




       }


$newarray |Export-Csv -Path "C:\Users\a583418\Desktop\finalexport.csv"