﻿import-module appvclient
Get-appvclientpackage | remove-appvclientpackage